// stdafx.cpp: archivo de c�digo fuente que contiene s�lo las inclusiones est�ndar
// Final Taller (Tanques2).pch ser� el encabezado precompilado
// stdafx.obj contiene la informaci�n de tipos precompilada

#include "stdafx.h"

// TODO: mencionar los encabezados adicionales que se necesitan en STDAFX.H
// pero no en este archivo
